﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class MenuImplementacion : MenuInterfaz
    {
        public int menuPrincipal()
        {
            int seleccionUsuario;
            Console.WriteLine("0. Cerrar Menu");
            Console.WriteLine("1. Registrar vehiculo");
            Console.WriteLine("2. Control de acceso");
            Console.WriteLine("3. Acceso PIF");
            seleccionUsuario= Convert.ToInt32(Console.ReadLine());
            return seleccionUsuario;
        }
        public int controlAcceso()
        {

            int opcionAcceso;
            Console.WriteLine("CONTROL DE ACCESO");
            Console.WriteLine("0. Volver");
            Console.WriteLine("1. ESTE");
            Console.WriteLine("2. OESTE");
            Console.WriteLine("3. NORTE");
            Console.WriteLine("seleccione una opcion");
            opcionAcceso = Convert.ToInt32(Console.ReadLine());
            return opcionAcceso;
        }
    }
}
