﻿using examenSimulacroPUERTO.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class ControlAccesoImplementacion : ControlAccesoInterfaz
    {
        PifInterfaz pif = new PifImplementacion();
        public void accesoPuertaEste()
        {
            Console.WriteLine("REGISTRO ZONA ESTE");
            Console.WriteLine("Ingrese Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("ESTE") && vehiculo.Mercancia.Equals(true) && (vehiculo.TipoVehiculo.Equals('F') || vehiculo.TipoVehiculo.Equals('A')))
                    {
                        pif.accesoPIF();
                        /*
                       //QUIZA ESTO PUEDE QUITARSE PORQUE ARRIBA YA ESTOY PONIENDO LA CONDICION DE QUE LLEVAR MERCANCIA ES TRUE
                        Console.WriteLine("El vehiculo transporta alguna mercancia? (S/N):");
                        char sn = char.Parse(Console.ReadLine().ToUpper());
                        bool isMercancia;
                        if (sn == 'S')
                        {
                            isMercancia = true;
                            pif.accesoPIF();
                        }
                        else

                        {
                            isMercancia = false;
                            vehiculo.DestinoVehiculo = "SN";
                            vehiculo.Mercancia = false;
                            Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER. TIENE QUE DIRIGIRSE A SN");
                        }
                        /*vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        vehiculo.DestinoVehiculo = "NORTE";*/
                       
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }

                    
                }
                else
                {
                    Console.WriteLine("No se encontró ningun vehiculo registrado con esa matricula, vuelva a acceso principal y registrese");
                }
            }
        }



        public void accesoPuertaNorte()
        {
            Console.WriteLine("REGISTRO ZONA NORTE");
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("NORTE") && vehiculo.Mercancia.Equals(false) &&
                        (vehiculo.TipoVehiculo.Equals('F') || vehiculo.TipoVehiculo.Equals('A')))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        //fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona SN");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
                else
                {
                    Console.WriteLine("No se encontró ningun vehiculo registrado con esa matricula. Intente nuevamente");
                }
            }
        }

        public void accesoPuertaOeste()
        {
            Console.WriteLine("REGISTRO ZONA OESTE");
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("OESTE") && vehiculo.TipoVehiculo.Equals('P'))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        //fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona SO");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
            }
        }


    }
}

    

