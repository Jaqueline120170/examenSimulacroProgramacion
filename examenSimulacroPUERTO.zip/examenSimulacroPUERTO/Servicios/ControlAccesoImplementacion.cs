﻿using examenSimulacroPUERTO.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class ControlAccesoImplementacion : ControlAccesoInterfaz
    {
        public void accesoPuertaEste()
        {
            Console.WriteLine("Ingrese Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("ESTE") && (vehiculo.TipoVehiculo.Equals('F') || vehiculo.TipoVehiculo.Equals('A')))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        vehiculo.DestinoVehiculo = "EN";
                        
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }

                    
                }
                else
                {
                    Console.WriteLine("No se encontró ningun vehiculo registrado con esa matricula");
                }
            }
        }



        public void accesoPuertaNorte()
        {
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("NORTE") && vehiculo.Mercancia.Equals(false) &&
                        (vehiculo.TipoVehiculo.Equals('F') || vehiculo.TipoVehiculo.Equals('A')))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        //fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona SN");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
                else
                {
                    Console.WriteLine("No se encontró ningun vehiculo registrado con esa matricula. Intente nuevamente");
                }
            }
        }

        public void accesoPuertaOeste()
        {
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("SO") && vehiculo.TipoVehiculo.Equals('P'))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        //fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona SO");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
            }
        }


    }
}

    

