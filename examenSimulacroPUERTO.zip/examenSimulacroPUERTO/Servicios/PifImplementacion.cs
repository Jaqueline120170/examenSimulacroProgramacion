﻿using examenSimulacroPUERTO.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class PifImplementacion : PifInterfaz
    {
        public void accesoPIF()
        {
          VehiculosDto vehiculo = new VehiculosDto();
                        Console.WriteLine("La mercancia que transporta es apta? (S/N):");
                        char respuesta = char.Parse(Console.ReadLine().ToUpper());
                        bool esApta;
                        if(respuesta == 'S')
                        {
                            esApta = true;

                            vehiculo.FechaIngreso = DateTime.Now;
                            vehiculo.DestinoVehiculo = "NORTE";
                            Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + vehiculo.MatriculaVehiculo +
                                ", PUEDE DIRIGIRSE A LA ZONA " + vehiculo.DestinoVehiculo + " VEHICULO CON MERCANCIA: APTA");
                            

                        }
                        else
                        {
                            esApta= false;
                            vehiculo.DestinoVehiculo = "SUR";
                            Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + vehiculo.MatriculaVehiculo +
                               ", PUEDE DEBE DIRIGIRSE A LA ZONA: " + vehiculo.DestinoVehiculo + "VEHICULO CON MERCANCIA: NO APTA");
                        }
                            
                        
                        
                   
                
            
        }

        public void accesoEN(List<VehiculosDto> listaVehiculos)
        {
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.MatriculaVehiculo.Equals(matricula))
                {
                    if (vehiculo.DestinoVehiculo.Equals("EN") && vehiculo.Mercancia.Equals(true))
                    {
                        vehiculo.FechaIngreso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaIngreso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.DestinoVehiculo);
                        //fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona EN");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
            }
        }
        public void revision()
        {
            int contador = 0;
            burbuja();
            foreach (VehiculosDto var 
                in Program.listaVehiculos)
            {
                if (var.Mercancia == false)
                {
                    contador++;
                    var.FechaIngreso = DateTime.Now;
                    var.DestinoVehiculo = "norte";
                    Program.listaVehiculos.Add(var);

                }
            }
            if (contador == 0)
            {
                Console.WriteLine("No hay ningun vehiculo apto");
            }
            else if (contador == 1)
            {
                Console.WriteLine($"Hay {contador} vehiculo apto");
            }
            else
            {
                Console.WriteLine($"Hay {contador} vehiculos aptos");
            }
        }

        private void burbuja()
        {
            if (Program.listaVehiculos.Count() >= 3)
            {
                for (int i = 0; i < Program.listaVehiculos.Count() - 1; i++)
                {
                    for (int j = 0; j < Program.listaVehiculos.Count() - 1 - i; j++)
                    {
                        if (Program.listaVehiculos[j].IdVehiculo > Program.listaVehiculos[j + 1].IdVehiculo)
                        {
                            VehiculosDto aux = Program.listaVehiculos[j];
                            Program.listaVehiculos[j] = Program.listaVehiculos[j + 1];
                            Program.listaVehiculos[j + 1] = aux;
                        }
                    }
                }
            }

        }

    }
}
