﻿using examenSimulacroPUERTO.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class PifImplementacion : PifInterfaz
    {
        public void accesoPIF()
        {
            foreach (VehiculosDto vehiculo in Program.listaVehiculos)
            {
                if (vehiculo.DestinoVehiculo.Equals("ESTE"))
                {
                    Console.WriteLine("El vehiculo transporta alguna mercancia? (S/N):");
                    char transporte = Convert.ToChar(Console.ReadLine());
                    if (transporte == 'S')
                    {
                        vehiculo.FechaPaso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaPaso + ": EL VEHICULO CON MATRICULA: " + vehiculo.Matricula +
                            ", PUEDE DIRIGIRSE A LA ZONA " + vehiculo.Destino);
                        Console.WriteLine("EL VEHICULO CON MATRICULA: " + vehiculo.Matricula + " PUEDE DIRIGIRSE A EN");
                    }
                    else
                    {
                        vehiculo.Destino = "SN";
                        vehiculo.Mercancia = false;
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER. TIENE QUE DIRIGIRSE A SN");
                    }
                }
            }
        }

        public void accesoEN(List<Vehiculo> listaVehiculos)
        {
            Console.WriteLine("Matricula:");
            string matricula = Console.ReadLine();

            foreach (Vehiculo vehiculo in listaVehiculos)
            {
                if (vehiculo.Matricula.Equals(matricula))
                {
                    if (vehiculo.Destino.Equals("EN") && vehiculo.Mercancia.Equals(true))
                    {
                        vehiculo.FechaPaso = DateTime.Now;
                        Console.WriteLine(vehiculo.FechaPaso + ": EL VEHICULO CON MATRICULA: " + matricula + ", PUEDE ACCEDER A LA ZONA "
                            + vehiculo.Destino);
                        fi.sobrescribirFichero("El vehiculo con matricula: " + matricula + " se encuentra en zona EN");
                    }
                    else
                    {
                        Console.WriteLine("EL VEHICULO NO PUEDE ACCEDER");
                    }
                }
            }
        }
        public void revision()
        {
            int contador = 0;
            burbuja();
            foreach (VehiculosDto var 
                in Program.listaVehiculos)
            {
                if (var.Mercancia == false)
                {
                    contador++;
                    var.FechaIngreso = DateTime.Now;
                    var.DestinoVehiculo = "norte";
                    Program.listaVehiculos.Add(var);

                }
            }
            if (contador == 0)
            {
                Console.WriteLine("No hay ningun vehiculo apto");
            }
            else if (contador == 1)
            {
                Console.WriteLine($"Hay {contador} vehiculo apto");
            }
            else
            {
                Console.WriteLine($"Hay {contador} vehiculos aptos");
            }
        }

        private void burbuja()
        {
            if (Program.listaVehiculos.Count() >= 3)
            {
                for (int i = 0; i < Program.listaVehiculos.Count() - 1; i++)
                {
                    for (int j = 0; j < Program.listaVehiculos.Count() - 1 - i; j++)
                    {
                        if (Program.listaVehiculos[j].IdVehiculo > Program.listaVehiculos[j + 1].IdVehiculo)
                        {
                            VehiculosDto aux = Program.listaVehiculos[j];
                            Program.listaVehiculos[j] = Program.listaVehiculos[j + 1];
                            Program.listaVehiculos[j + 1] = aux;
                        }
                    }
                }
            }

        }

    }
}
