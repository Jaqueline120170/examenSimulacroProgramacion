﻿using examenSimulacroPUERTO.Dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Servicios
{
    internal class VehiculoImplementacion : VehiculoInterfaz
    {
        public void registrarVehiculo()
        {
            string agregarOtro;
            do
            {
                Console.WriteLine("ACCESO PRINCIPAL PUERTA SUR");
                long id = Utilidades.util.calcularIdVehiculo();
                Console.WriteLine("Introduzca la matricula del vehiculo");
                string matricula = Console.ReadLine();
                Console.WriteLine("Seleccione el tipo de vehiculo P(partiular, F(frigorifico), A(articulado) ");
                char tipo = Convert.ToChar(Console.ReadLine().ToUpper());

                Console.WriteLine("El vehiculo lleva mercancia  s/n?");
                char sn = char.Parse(Console.ReadLine().ToLower());

                bool isMercancia;
                 

                if (sn == 's')
                {
                    isMercancia = true;
                }
                else
                {
                    isMercancia = false;
                }
                DateTime fechaEntrada = DateTime.Now;

                //Creacion del vehiculo
                VehiculosDto vehiculo = new VehiculosDto(id, matricula, tipo, isMercancia, fechaEntrada);


                string zonaDestino = primerFiltroAcceso(vehiculo);
                vehiculo.DestinoVehiculo = zonaDestino;
                Console.WriteLine("ZONA ASIGNADA : " + zonaDestino);
                Console.WriteLine("Dirijase al control de acceso y seleccione la zona asignada");

                //Añadir el vehiculo a la lista estatica de vehiculos para que se guarde y acceder a ella sin tener que instanciar
                Program.listaVehiculos.Add(vehiculo);
                Console.WriteLine("¿Desea añadir otro vehiculo? si/no");
                agregarOtro = Console.ReadLine().ToLower();
            } while (agregarOtro.Equals("si"));

        }
        private static string primerFiltroAcceso(VehiculosDto vehiculo)
        {
            // Implementar las condiciones de asignación de zona de destino
            string zona;
            if (vehiculo.TipoVehiculo == 'P')
            {
               
                zona = "OESTE";
                return zona;
            }
            else if ((vehiculo.TipoVehiculo == 'F' || vehiculo.TipoVehiculo == 'A') && !vehiculo.Mercancia)
            {
              
                zona = "NORTE";
                return zona;
            }
            else if ((vehiculo.TipoVehiculo == 'F' || vehiculo.TipoVehiculo == 'A') && vehiculo.Mercancia )
            {
              
                zona = "ESTE";
                return zona;
            }
            else
            {
                return "No se puede asignar zona a este vehiculo";
            }
        }
        
    }
        

       
     
}
