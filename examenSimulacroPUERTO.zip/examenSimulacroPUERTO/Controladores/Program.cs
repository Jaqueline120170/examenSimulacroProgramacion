﻿
using examenSimulacroPUERTO.Dtos;
using examenSimulacroPUERTO.Servicios;
using System.Security.Cryptography.X509Certificates;

namespace examenSimulacroPUERTO
{
    class Program
    {
        /// <summary>
        /// Listas declaradas de forma estatica para poder acceder a ellas desde cualquier parte del codigo
        /// </summary>
        public static List<VehiculosDto> listaVehiculos = new List<VehiculosDto>();
        public static void Main(string[] args)
        {
           ///Constructores de clases e interfaces
           MenuInterfaz mi = new MenuImplementacion();
           VehiculoInterfaz vi = new VehiculoImplementacion();
           ControlAccesoInterfaz ci = new ControlAccesoImplementacion();
           PifInterfaz pi = new PifImplementacion();


            int opcion;
            bool cerrarMenu=false;

            while(!cerrarMenu)
            {
                opcion = mi.menuPrincipal();
                switch(opcion)
                {
                    case 0:
                        cerrarMenu = true;
                        break;
                    case 1:
                        vi.registrarVehiculo();
                        break;
                    case 2:
                        if (listaVehiculos.Count > 0)
                        {
                            int opcionPuertas = mi.controlAcceso();
                            switch (opcionPuertas)
                            {
                                case 1:
                                    ci.accesoPuertaEste();

                                    break;
                                case 2:
                                    ci.accesoPuertaOeste();
                                    break;
                                case 3:
                                    ci.accesoPuertaNorte();
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Debes de añadir como inimo algun vehiculo");
                        }

                        break;
                    case 3:
                        pi.accesoPIF();
                        break;
                    default:
                        Console.WriteLine("SELECCIONE OPCION VALIDA");
                        break;
                }
            }

        }
    }
}