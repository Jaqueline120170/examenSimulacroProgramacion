﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Dtos
{
    internal class VehiculosDto
    {
        /// <summary>
        /// Propiedades del objeto vehiculoDto
        /// </summary>
        long idVehiculo;
        string matriculaVehiculo;
        char tipoVehiculo;
        string destinoVehiculo;
        bool mercancia;
        DateTime fechaIngreso;


        /// <summary>
        /// Constructor vacío
        /// </summary>
        public VehiculosDto()
        {
        }

        public VehiculosDto(long idVehiculo, string matriculaVehiculo, char tipoVehiculo, bool mercancia, DateTime fechaIngreso)
        {
            this.idVehiculo = idVehiculo;
            this.matriculaVehiculo = matriculaVehiculo;
            this.tipoVehiculo = tipoVehiculo;
            this.destinoVehiculo = destinoVehiculo;
            this.mercancia = mercancia;
            this.fechaIngreso = fechaIngreso;
        }




        /// <summary>
        /// Métodos de acceso getters y setters
        /// </summary>

        public long IdVehiculo { get => idVehiculo; set => idVehiculo = value; }
        public string MatriculaVehiculo { get => matriculaVehiculo; set => matriculaVehiculo = value; }
        public char TipoVehiculo { get => tipoVehiculo; set => tipoVehiculo = value; }
        public string DestinoVehiculo { get => destinoVehiculo; set => destinoVehiculo = value; }
        public bool Mercancia { get => mercancia; set => mercancia = value; }
        public DateTime FechaIngreso { get => fechaIngreso; set => fechaIngreso = value; }
    }
}
