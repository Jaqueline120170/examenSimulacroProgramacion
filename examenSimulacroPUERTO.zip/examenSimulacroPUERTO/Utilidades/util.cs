﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace examenSimulacroPUERTO.Utilidades
{
    internal class util
    {
        public static long calcularIdVehiculo()
        {

            long idV = 0;
            int tamanio = Program.listaVehiculos.Count;

            if (tamanio > 0)
            {

                idV = Program.listaVehiculos[tamanio - 1].IdVehiculo + 1;

            }
            else
            {

                idV = 1;

            }

            return idV;
        }
    }
}
